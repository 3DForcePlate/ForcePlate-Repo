﻿


#imports from vizard library
import viz
import vizconnect
import vizact 
import viztask
import vizmat
import vizfx
import oculus
import vizshape

#imports from python library
import math
import random
import sys
import collections
import os
import time
import csv
import gzip
import ctypes
from time import sleep
import threading

# in Python 2 this is Queue, but in 3 it is Queue
import Queue


import serial
import serial.tools.list_ports

import numpy as np 


def quit_and_disconnect():
	# if (EndofPlay_Flag == False) and (Play_Flag == True) and (Reset_Flag == False) and (EndofReset_Flag == True):
		# imu_reset()
		# imu_disconnect()
	viz.quit()
	sys.exit()




def get_ports():

    ports = serial.tools.list_ports.comports()
    
    return ports

def findArduino(portsFound):
    
    commPort = 'None'
    numConnection = len(portsFound)
    
    for i in range(0,numConnection):
        port = foundPorts[i]
        strPort = str(port)
        
        # look in Device Manager list to see the names of devices connected to USB ports
        # use the first word in the name of the device that you are looking for
        if 'USB' in strPort: 
            splitPort = strPort.split(' ')
            commPort = (splitPort[0])

    return commPort
            


def micros():
    "return a timestamp in microseconds (us)"
    tics = ctypes.c_int64() #use *signed* 64-bit variables; see the "QuadPart" variable here: https://msdn.microsoft.com/en-us/library/windows/desktop/aa383713(v=vs.85).aspx 
    freq = ctypes.c_int64()

    #get ticks on the internal ~2MHz QPC clock
    ctypes.windll.Kernel32.QueryPerformanceCounter(ctypes.byref(tics)) 
    #get the actual freq. of the internal ~2MHz QPC clock
    ctypes.windll.Kernel32.QueryPerformanceFrequency(ctypes.byref(freq))  
    
    t_us = tics.value*1e6/freq.value
    return t_us
        
def millis():
    "return a timestamp in milliseconds (ms)"
    tics = ctypes.c_int64() #use *signed* 64-bit variables; see the "QuadPart" variable here: https://msdn.microsoft.com/en-us/library/windows/desktop/aa383713(v=vs.85).aspx 
    freq = ctypes.c_int64()

    #get ticks on the internal ~2MHz QPC clock
    ctypes.windll.Kernel32.QueryPerformanceCounter(ctypes.byref(tics)) 
    #get the actual freq. of the internal ~2MHz QPC clock 
    ctypes.windll.Kernel32.QueryPerformanceFrequency(ctypes.byref(freq)) 
    
    t_ms = tics.value*1e3/freq.value
    return t_ms
 
    
#-see here for example of constrain function: http://stackoverflow.com/questions/34837677/a-pythonic-way-to-write-a-constrain-function/34837691
def constrain(val, min_val, max_val):
    # "constrain a number to be >= min_val and <= max_val"
    if (val < min_val): 
        val = min_val
    elif (val > max_val): 
        val = max_val
    return val

#Other timing functions:
def delay(delay_ms):
    # "delay for delay_ms milliseconds (ms)"
    # constrain the commanded delay time to be within valid C type uint32_t limits 
    delay_ms = _constrain(delay_ms, 0, (1<<32)-1)
    t_start = millis()
    while ((millis() - t_start)%(1<<32) < delay_ms): #use modulus to force C uint32_t-like underflow behavior 
        pass #do nothing 
    return

def delayMicroseconds(delay_us):
    # "delay for delay_us microseconds (us)"
    # constrain the commanded delay time to be within valid C type uint32_t limits 
    delay_us = constrain(delay_us, 0, (1<<32)-1)
    t_start = micros()
    #   %  Modulus	Divides left hand operand by right hand operand and returns remainder
    while ((micros() - t_start)%(1<<32) < delay_us): #use modulus to force C uint32_t-like underflow behavior
        pass #do nothing 
    return 



	
def objects_kinematics():
	
	global IMU_data_values, IMU_data_time_value, startTime, foundPorts, connectPort
	global collection_time, accel_x, accel_y, accel_z, omega_x, omega_y, omega_z
	global input_flag
	
	
	class ReadLine:
		def __init__(self, s):
			self.buf = bytearray()
			self.s = s
		
		def readline(self):
			i = self.buf.find(b"\n")
			if i >= 0:
				r = self.buf[:i+1]
				self.buf = self.buf[i+1:]
				return r
			while True:
				i = max(1, min(2048, self.s.in_waiting))
				data = self.s.read(i)
				i = data.find(b"\n")
				if i >= 0:
					r = self.buf + data[:i+1]
					self.buf[0:] = data[i+1:]
					return r
				else:
					self.buf.extend(data)
	
	
	def get_imu_data_values(inputQueue):
		global input_flag
		
		input_flag = False
		while True:
			rl = ReadLine(ser)
			arduinoData = rl.readline()
			
			IMU_data_string = str(arduinoData)
			
			inputQueue.put(IMU_data_string)
			# after the initial connection to the USB port to read "Node 1 Ready"
			# set the flag now to start data capture
			input_flag = True
		
		return 

	
	def convert_string_to_float(IMU_data_string):
		
		"""
		# Defining splitting point - floating point numbers are 9 spaces with 2 decimal points
		n = 9
		  
		# Using list comprehension
		IMU_data_str_list = [(IMU_data_string[i:i+n]) for i in range(0, len(IMU_data_string), n)]
		"""
		splitString = IMU_data_string.split(' ')
		IMU_data_float = np.zeros(6)
		IMU_data_integers = np.zeros(6)
		
		for i in range(0,6):
			IMU_data_integers[i] = int(splitString[i])
			
		IMU_data_float[0] = float(24.0*9.81*IMU_data_integers[0]/32767)
		IMU_data_float[1] = float(24.0*9.81*IMU_data_integers[1]/32767)
		IMU_data_float[2] = float(24.0*9.81*IMU_data_integers[2]/32767)
		IMU_data_float[3] = float(2000.0*IMU_data_integers[3]/32767)
		IMU_data_float[4] = float(2000.0*IMU_data_integers[4]/32767)
		IMU_data_float[5] = float(2000.0*IMU_data_integers[5]/32767)
		
		# the data values are accel_x, accel_y, accel_z, ang_vel_x, ang_vel_y, ang_vel_z
		return IMU_data_float
	
	
	
	
	# initialize the com port for data collection
	
	foundPorts = get_ports()        
	connectPort = findArduino(foundPorts)

	print(foundPorts)
	print(connectPort)

	if connectPort != 'None':
		ser = serial.Serial(connectPort,baudrate = 2000000, timeout=1)
		print('Connected to ' + connectPort)

	else:
		print('Connection Issue!')
		quit_and_disconnect()
	
	
	# initialize variables
	
	IMU_data_values = np.zeros(6)
	
	relativeTime = 0
	startTime = 0
	currentTime = 0
	IMU_data_time_value = 0
	
	ball_current_position = [0,0,0]
	ball_prior_position = [0,0,0]
	tracker_position = [0,0,0]
	tracker_orientation = [0,0,0,0]
	imu_current_position = [0,0,0]
	imu_prior_position = [0,0,0]
	imu_current_orientation = [0,0,0,0]
	imu_prior_orientation = [0,0,0,0]
	
	barrel_min_position = [0,0,0]
	barrel_center_position = [0,0,0]
	barrel_max_position = [0,0,0]
	
	bat_rod_position = [0,0,0]
	hand_position = [0,0,0]
	
	collection_time = np.zeros(200)	
	accel_x = np.zeros(200)
	accel_y = np.zeros(200)
	accel_z = np.zeros(200)
	omega_x = np.zeros(200)
	omega_y = np.zeros(200)
	omega_z = np.zeros(200)
	
	rl = ReadLine(ser)
	arduinoData = rl.readline()
	
	
	
	
	inputQueue = Queue.Queue()
	
	inputThread = threading.Thread(target=get_imu_data_values,args=(inputQueue,))
	inputThread.start()
	
	
	# move this to where code is triggered at pitch start
	# set initial start time before collecting data
	startTime = micros()
	print("start time = ", startTime)
	
	i = 0
	while i < 200:
		
		if inputQueue.qsize() > 0:
			IMU_data_string = inputQueue.get()
			
			IMU_data_values = convert_string_to_float(IMU_data_string)
			# print(IMU_data_values)
			# get time stamps for IMU data
			currentTime = micros()
			if (startTime < currentTime): 
				relativeTime = currentTime - startTime
			else:
				#  <<   Binary Left Shift	The left operands value is moved left by 
				# the number of bits specified by the right operand.
				# calculate the time if the counter rolled over back to zero
				relativeTime = (((1<<64)-1) - startTime) + currentTime
			
			# convert time to seconds
			IMU_data_time_value = float(relativeTime/1000000.0)
			
			collection_time[i] = IMU_data_time_value	 
			accel_x[i] = IMU_data_values[0]
			accel_y[i] = IMU_data_values[1]
			accel_z[i] = IMU_data_values[2]
			omega_x[i] = IMU_data_values[3]
			omega_y[i] = IMU_data_values[4]
			omega_z[i] = IMU_data_values[5]
				
			# print(IMU_data_time_value, IMU_data_values)

			i += 1
		

# viz.director(objects_kinematics)

objects_kinematics()

file_name = './IMU_Data.csv'
data_filename = viz.res.getPublishedPath(file_name)
			
# Save the vector arrays as columns using numpy.c_[]
# A - time (s)
np.savetxt(data_filename, np.c_[collection_time, \
# B, C, D,
accel_x, accel_y, accel_z,  \
# E, F, G,
omega_x, omega_y, omega_z], delimiter=',')



















