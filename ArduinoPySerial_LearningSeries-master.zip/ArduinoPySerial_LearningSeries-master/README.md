# ArduinoPySerial_LearningSeries

This repository is for those who would like to learn how to use the Python module PySerial and Arduino.
There will be a corresponding Arduino (.ino) and Python (.py) file for each part. Each part builds upon the previous.
View the YouTube Play List for step by step instruction and detailed instructions:
https://www.youtube.com/playlist?list=PLb1SYTph-GZJb1CFM7ioVY9XJYlPVUBQy

WaveShapePlay
