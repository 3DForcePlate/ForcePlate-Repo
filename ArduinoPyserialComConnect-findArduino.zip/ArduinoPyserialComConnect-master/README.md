# ArduinoPyserialComConnect
This code is developed to detect the USB to Serial devices connected to your computer and pick out the Arduino!
